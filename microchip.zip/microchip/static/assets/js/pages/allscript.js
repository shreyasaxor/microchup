// A $( document ).ready() block.
function CallInitailaldata(){

$.ajax({
    url : "/get-data",
    type: "Get",
       success: function(data, textStatus, jqXHR)
    {
        console.log(data)
        FillDropHtmlOptions(data)
    },
    error: function (jqXHR, textStatus, errorThrown)
    {

    }
});



}

function FillDropHtmlOptions(data){
console.log(data['data'][0])
$('#Selection_options').empty()
$('#Complexity_options').empty()
$('#Priority_options').empty()
$('#Selection_options').append('<option value="" selected disabled>Select</option>')
$('#Complexity_options').append('<option value="" selected disabled>Select</option>')
$('#Priority_options').append('<option value="" selected disabled>Select</option>')

    for(var i=0;i<data['data'][0]['Section'].length;i++){
     $('#Selection_options').append("<option value="+data['data'][0]['Section'][i]+">"+data['data'][0]['Section'][i]+"</option>")
    }

    for(var i=0;i<data['data'][1]['Complexity'].length;i++){
     $('#Complexity_options').append("<option value="+data['data'][1]['Complexity'][i]+">"+data['data'][1]['Complexity'][i]+"</option>")
    }

    for(var i=0;i<data['data'][2]['Priority'].length;i++){
     $('#Priority_options').append("<option value="+data['data'][2]['Priority'][i]+">"+data['data'][2]['Priority'][i]+"</option>")
    }

}


$( document ).ready(function() {
    console.log( "ready!" );
    CallInitailaldata()


});


function PostData(formData){

$.ajax({
    url : "/get-data",
    type: "POST",
    data : formData,
       success: function(data, textStatus, jqXHR)
            {
                console.log(data)
            },
    error: function (jqXHR, textStatus, errorThrown)
            {

            }

})

    $.ajax({
    url : "/get-optimized-data",
    type: "POST",
    data : formData,
       success: function(data, textStatus, jqXHR)
            {
                console.log(data)
            },
    error: function (jqXHR, textStatus, errorThrown)
            {

            }

})

    $.ajax({
    url : "/get-difference-data",
    type: "POST",
    data : formData,
       success: function(data, textStatus, jqXHR)
            {
                console.log(data)
            },
    error: function (jqXHR, textStatus, errorThrown)
            {

            }

})


}






$("#GetChartData").click(function(){
    var formData = {}
    if($('#Selection_options').val()){

        formData['section']=$('#Selection_options option:selected').text()

    }
    if($('#Complexity_options').val()){

        formData['complexity']=$('#Complexity_options option:selected').text()

    }
    if($('#Priority_options').val()){

        formData['priority']=$('#Priority_options option:selected').text()

    }
console.log(formData,">>>")

    PostData(JSON.stringify(formData))

});



