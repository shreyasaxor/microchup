var options = {
    chart: {
        height: 159,
        type: "bar",
        stacked: !0,
        toolbar: {
            show: !1
        },
        zoom: {
            enabled: !0
        }
    },
    plotOptions: {
        bar: {
            horizontal: !1,
            columnWidth: "15%",
            endingShape: "rounded"
        }
    },
    dataLabels: {
        enabled: !1
    },
    series: [{
        name: "Series A",
        data: [44, 55, 41, 67, 202]
    }],
    xaxis: {
        categories: ["Jan", "Feb", "Mar", "Apr", "May"]
    },
    colors: ["#556ee6"],
    legend: {
        position: "bottom"
    },
    fill: {
        opacity: 1
    }
};
(chart = new ApexCharts(document.querySelector("#stacked-column-chart"), options)).render();
var chart;

var options2 = {
    chart: {
        height: 159,
        type: "bar",
        stacked: !0,
        toolbar: {
            show: !1
        },
        zoom: {
            enabled: !0
        }
    },
    plotOptions: {
        bar: {
            horizontal: !1,
            columnWidth: "15%",
            endingShape: "rounded"
        }
    },
    dataLabels: {
        enabled: !1
    },
    series: [{
        name: "Series A",
        data: [44, 55, 41, 67, 22]
    }],
    xaxis: {
        categories: ["Jan", "Feb", "Mar", "Apr", "May"]
    },
    colors: ["#fab256"],
    legend: {
        position: "bottom"
    },
    fill: {
        opacity: 1
    }
};
(chart = new ApexCharts(document.querySelector("#stacked-column-chart2"), options2)).render();
var chart;

var options3 = {
    chart: {
        height: 159,
        type: "bar",
        stacked: !0,
        toolbar: {
            show: !1
        },
        zoom: {
            enabled: !0
        }
    },
    plotOptions: {
        bar: {
            horizontal: !1,
            columnWidth: "15%",
            endingShape: "rounded"
        }
    },
    dataLabels: {
        enabled: !1
    },
    series: [{
        name: "Series A",
        data: [44, 55, 41, 67, 22]
    }],
    xaxis: {
        categories: ["Jan", "Feb", "Mar", "Apr", "May"]
    },
    colors: ["#fab256"],
    legend: {
        position: "bottom"
    },
    fill: {
        opacity: 1
    }
};
(chart = new ApexCharts(document.querySelector("#stacked-column-chart_o"), options3)).render();
var chart;

var options3 = {
    chart: {
        height: 159,
        type: "bar",
        stacked: !0,
        toolbar: {
            show: !1
        },
        zoom: {
            enabled: !0
        }
    },
    plotOptions: {
        bar: {
            horizontal: !1,
            columnWidth: "15%",
            endingShape: "rounded"
        }
    },
    dataLabels: {
        enabled: !1
    },
    series: [{
        name: "Series A",
        data: [44, 55, 41, 67, 22]
    }],
    xaxis: {
        categories: ["Jan", "Feb", "Mar", "Apr", "May"]
    },
    colors: ["#fab256"],
    legend: {
        position: "bottom"
    },
    fill: {
        opacity: 1
    }
};
(chart = new ApexCharts(document.querySelector("#stacked-column-chart2_o"), options3)).render();
var chart;
