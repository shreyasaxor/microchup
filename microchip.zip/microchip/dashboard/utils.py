import pandas as pd

import json
import os


def filter(fdata):

    filepath = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/media/optimised_test_cases.xlsx"
    df = pd.read_excel(filepath, 'full_data')
    endpoints={}

    if fdata.get("section"):
        section_filter = []
        section_filter.append(fdata.get("section"))
        endpoints.update({"Section":fdata.get("section")})
        df = df.loc[df['Section'].isin(section_filter)]

    if fdata.get("complexity"):
        complexity_filer = []
        complexity_filer.append(fdata.get("complexity"))
        endpoints.update({"Complexity": fdata.get("complexity")})
        df = df.loc[df['Complexity'].isin(complexity_filer)]

    if fdata.get("priority"):
        priority_filter = []
        priority_filter.append(fdata.get("priority"))
        endpoints.update({"Priority": fdata.get("priority")})
        df = df.loc[df['Priority'].isin(priority_filter)]

    df.to_json('media/temp.json', orient='records', lines=True)

    return df,endpoints

def getuniques():
    resulut= {}
    filepath = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/media/optimised_test_cases.xlsx"
    df = pd.read_excel(filepath, 'full_data')
    resulut=[{data:list(df[data].unique())} for data in ['Section','Complexity','Priority']]
    return resulut


def convertjson(endpoints):
    entities = ['Section','Complexity','Priority','Test_Title']
    result =[]
    with open('media/temp.json') as f:
        data = f.readlines()
    for line in data:
        result.append(json.loads(line))

    if len(endpoints) == 0:
        # one to next one
        print(endpoints, "endpointsendpoints>>>>>>>>>>endpoints")

        data = 'Section'

    if len(endpoints)==3:
        data ='Test_Title'

    if len(endpoints)==2:
        if 'Priority' in endpoints.keys():
            data ='Test_Title'
        else:
            data = 'Priority'

    if len(endpoints)==1:
        # one to next one
        print(endpoints,"endpointsendpoints>>>>>>>>>>endpoints")
        index  =entities.index(list(endpoints.keys())[0])
        data =entities[index+1]

    print(data)
    return result ,data

def uniquecounter(results,data):
    counts = {}
    effort ={}
    for res in results:
        print(res['Estimate(in Mins)'])
        if res.get(data,None):
            var =counts.get(res.get(data),0)
            counts.update({res.get(data):var+1})
            pre =effort.get(res.get(data),0)
            effort.update({res.get(data):pre+res.get('Estimate(in Mins)')})
    return counts,effort