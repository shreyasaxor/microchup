from django.shortcuts import render
from rest_framework.views import APIView,View
from rest_framework.response import Response
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from .utils import filter, convertjson, getuniques, uniquecounter
import json
# Create your views here.

class DashBoard(APIView):
    def get(self,request,*args,**kwargs):
        return render(request,template_name='index.html')
dashboard = DashBoard.as_view()



@method_decorator(csrf_exempt, name='dispatch')
class GetDashboardData(View):
    def post(self,request,*args,**kwargs):
        try:
            fdata= json.loads(request.body.decode('utf-8'))
        except:

            fdata={}

        data,endpoints = filter(fdata) #filter and convet to json file
        print(endpoints)
        results,selected_entity=convertjson(endpoints) #convert in to json identify the displayable entty
        print(selected_entity,">>>>>")
        counts,time = uniquecounter(results,selected_entity)
        return JsonResponse({'tiem':time,'DataSize':len(results),'QualifiedEntity':selected_entity,'ChartData':counts,'TableData':results})



    def get(self,request,*args,**kwargs):
        results = getuniques()
        return JsonResponse({'data':results})

get_dashboard_data = GetDashboardData.as_view()